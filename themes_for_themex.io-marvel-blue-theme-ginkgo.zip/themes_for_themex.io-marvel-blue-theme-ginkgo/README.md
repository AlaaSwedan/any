Amazing themes for Open edX platform! https://themex.io/

#How to Install the Theme

Please find the information about how to install the theme from themeX on the website https://themex.io/install/

#License

#FAQ

#Issue Tracker

